<html>

<head>
    <style>
        h1 {
            color: blue;
            text-align: center;
        }

        h3 {
            color: blue;
            text-align: center;
        }

        .linea {
            border-bottom: 5px solid blue;
        }
    </style>
</head>

<body>
    <h1> Agenda </h1>
    <h1 class="linea"></h1>

    <h3><a href="mostrarAgenda.php">Mostrar Agenda</a></h3>
    <h3><a href="nuevoContacto.php">Nuevo Contacto</a></h3>
    <h3><a href="obtenerContacto.php">Mostrar Contacto</a></h3>
</body>

</html>